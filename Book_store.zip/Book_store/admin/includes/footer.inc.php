<div id="footer-wrap">
	<p id="legal">(c) 2010 OurSite. Design by <a href="http://www.phptpoint.com"> PHP-t-POINT</a>.</p>
	</div>