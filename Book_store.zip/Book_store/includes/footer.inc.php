<div id="footer-wrap">
	<p id="legal">&copy; 2018 Naman Patel</a> </p>
	</div>